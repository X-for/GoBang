package exchange_Rate_Converter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

public class MyChangeWindow extends JFrame {
    RateChange rateChange = new RateChange();

    JTabbedPane tabbedPane = new JTabbedPane();

    // 设计主窗口界面

    public MyChangeWindow() {
        // 获取显示器屏幕大小
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        // heght = 1536 , width = 864
        // 设置窗口大小为屏幕大小一半
        setSize(screenSize.width / 2, screenSize.height / 2);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        createTab1();
        add(tabbedPane);
        Container con = new Container();
        con.add(rateChange);
        setTitle("钱币转换器");
    }


    private void createTab1() {
        rateChange.rateChangeTab();
        Container con = this.getContentPane(); // 创建容器
        con.add(rateChange); // 将棋盘添加到容器
        tabbedPane.addTab("ratechange" , rateChange);
    }

//    public static void rateChangeTab() {
//        RateChange rateChange = new RateChange();
//        HashMap<String, List<String>> countryInf = new HashMap<>();
//
//        // 测试代码块
//        RateChange.findCurrencys();
//        System.out.println(RateChange.currencys.get("GMD"));
//        // 测试代码块
//
//        JPanel panel = new JPanel(new GridBagLayout());
//
//        Vector<String> vector = new Vector<String>();
//        File file = new File("src/main/java/Rate/CurrencysData.txt");
//        try (Scanner fr = new Scanner(new FileReader(file))) {
//            while (fr.hasNextLine()) {
//                String country = fr.next();
////                String f = fr.next();
////                String code = fr.next();
////                文件更新后读取
////                var temp = new ArrayList<String>();
////                temp.add(Integer.parseInt(f),code);
////                countryInf.put(country,temp);
//                vector.add(country);
//            }
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        }
//
//        // 设置下拉列表1
//        JComboBox<String> jcBox1 = new JComboBox<>(vector);
//
//        GridBagConstraints pla1 = new GridBagConstraints();
//        pla1.gridx = 0;
//        pla1.gridy = 0;
//        pla1.weightx = 1.0;
//        pla1.weighty = 1.0;
//        pla1.fill = GridBagConstraints.NONE;
//        pla1.anchor = GridBagConstraints.NORTHWEST;
//        pla1.insets = new Insets(10, 10, 10, 10);
//
//        JLabel label1 = new JLabel("选择兑换所使用的货币");
//        JPanel labelPanel1 = new JPanel(new BorderLayout());
//        JPanel tabBox1 = new JPanel();
//        labelPanel1.add(label1, BorderLayout.WEST);
//        labelPanel1.add(Box.createHorizontalStrut(10), BorderLayout.CENTER);
//        labelPanel1.add(jcBox1, BorderLayout.EAST);
//        panel.add(labelPanel1, pla1);
//        //panel.add(jcBox1,pla1);
//        // 设置下列表1完成
//
//        // 设置下拉列表2
//        JComboBox<String> jcBox2 = new JComboBox<>(vector);
//
//        GridBagConstraints pla2 = new GridBagConstraints();
//        pla2.gridx = 1;
//        pla2.gridy = 0;
//        pla2.weightx = 1.0;
//        pla2.weighty = 1.0;
//        pla2.fill = GridBagConstraints.NONE;
//        pla2.anchor = GridBagConstraints.NORTHWEST;
//        pla2.insets = new Insets(10, 0, 10, 10);
//
//        JLabel label2 = new JLabel("想要兑换的货币");
//        JPanel labelPanel2 = new JPanel(new BorderLayout());
//        labelPanel2.add(label2, BorderLayout.WEST);
//        labelPanel2.add(Box.createHorizontalStrut(10), BorderLayout.CENTER);
//        labelPanel2.add(jcBox2, BorderLayout.EAST);
//        panel.add(labelPanel2, pla2);
////        panel.add(jcBox2,pla2);
////         设置下列表2完成
////
////         设置下拉列表选择之后用户会得到关于两国之间汇率和和货币符号缩写的信息
//
//
////        // 采用鼠标监听器来监听jcBox1和2的下拉选择框选择了什么
////        MouseListener countrySelection = new MouseListener() {
////            @Override
////            public void mouseClicked(MouseEvent e) {
////
////            }
////            @Override
////            public void mousePressed(MouseEvent e) {
////                String country_1 = (String) jcBox1.getSelectedItem();
////                String country_2 = (String) jcBox2.getSelectedItem();
////
////                JTextField message = new JTextField(country_1 + "对\n" + country_2 + "的汇率是\n");
////                // 设置文本框为不可编辑
////                message.setEditable(false);
////                // 设置文本框背景颜色、字体颜色、前景颜色
////                message.setBackground(Color.BLUE);
////                message.setForeground(Color.BLACK);
////                message.setFont(new Font("宋体", Font.BOLD, 20));
////                // 设置文本框长宽
////                message.setPreferredSize(new Dimension(200, 50));
////
////                GridBagConstraints pla3 = new GridBagConstraints();
////                pla3.gridx = 0;
////                pla3.gridy = 1;
////                pla3.weightx = 1.0;
////                pla3.weighty = 1.0;
////                pla3.fill = GridBagConstraints.NONE;
////                pla3.anchor = GridBagConstraints.NORTHWEST;
////                pla3.insets = new Insets(10, 0, 10, 10);
////                panel.add(message, pla3);
////            }
////
////            @Override
////            public void mouseReleased(MouseEvent e) {
////
////            }
////
////            @Override
////            public void mouseEntered(MouseEvent e) {
////
////            }
////
////            @Override
////            public void mouseExited(MouseEvent e) {
////
////            }
////        };
////        jcBox1.addMouseListener(countrySelection);
////        jcBox2.addMouseListener(countrySelection);
//
//
////        //Test2 采用内部匿名类动作监听器来监听jcBox1和2的下拉选择框选择了什么
////        ActionListener countrySelection = e -> {
////            String country_1 = (String) jcBox1.getSelectedItem();
////            String country_2 = (String) jcBox2.getSelectedItem();
////
////            JTextField message = new JTextField(country_1 + "对\n" + country_2 + "的汇率是\n");
////            // 设置文本框为不可编辑
////            message.setEditable(false);
////            // 设置文本框背景颜色、字体颜色、前景颜色
////            message.setBackground(Color.BLUE);
////            message.setForeground(Color.BLACK);
////            message.setFont(new Font("宋体", Font.BOLD, 20));
////            // 设置文本框长宽
////            message.setPreferredSize(new Dimension(200, 50));
////
////            GridBagConstraints pla3 = new GridBagConstraints();
////            pla3.gridx = 0;
////            pla3.gridy = 1;
////            pla3.weightx = 1.0;
////            pla3.weighty = 1.0;
////            pla3.fill = GridBagConstraints.NONE;
////            pla3.anchor = GridBagConstraints.NORTHWEST;
////            pla3.insets = new Insets(10, 0, 10, 10);
////
////            panel.add(message, pla3);
////
////        };
////
////        jcBox1.addActionListener(countrySelection);
////        jcBox2.addActionListener(countrySelection);
//
//
//        // Test3 采用ItemListener来监听
//        ItemListener countrySeletion = e -> {
//            if (e.getStateChange() == ItemEvent.SELECTED){
//                String country_1 = (String) jcBox1.getSelectedItem();
//                String country_2 = (String) jcBox2.getSelectedItem();
//
//                JTextField message = new JTextField(country_1 + "对\n" + country_2 + "的汇率是\n");
//                // 设置文本框为不可编辑
//                message.setEditable(false);
//                // 设置文本框背景颜色、字体颜色、前景颜色
//                message.setBackground(Color.BLUE);
//                message.setForeground(Color.BLACK);
//                message.setFont(new Font("宋体", Font.BOLD, 20));
//                // 设置文本框长宽
//                message.setPreferredSize(new Dimension(200, 50));
//
//                GridBagConstraints pla3 = new GridBagConstraints();
//                pla3.gridx = 0;
//                pla3.gridy = 1;
//                pla3.weightx = 1.0;
//                pla3.weighty = 1.0;
//                pla3.fill = GridBagConstraints.NONE;
//                pla3.anchor = GridBagConstraints.NORTHWEST;
//                pla3.insets = new Insets(10, 0, 10, 10);
//
//                panel.add(message, pla3);
//            }
//        };
//        jcBox1.addItemListener(countrySeletion);
//        jcBox2.addItemListener(countrySeletion);
//
//
//        //tabbedPane().addTab("汇率转换", panel);
//    }

}

