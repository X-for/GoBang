package exchange_Rate_Converter;//package exchange_Rate_Converter;
//
//import java.math.BigDecimal;
//import java.math.RoundingMode;
//import java.util.HashMap;
//import java.util.Map;
//
//import javafx.application.Application;
//import javafx.geometry.Insets;
//import javafx.geometry.Pos;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.control.ComboBox;
//import javafx.scene.control.Label;
//import javafx.scene.control.Tab;
//import javafx.scene.control.TabPane;
//import javafx.scene.control.TextField;
//import javafx.scene.layout.GridPane;
//import javafx.scene.layout.VBox;
//import javafx.stage.Stage;
//
//public class Test extends Application {
//
//    // 汇率
//    private Map<String, BigDecimal> rates = new HashMap<>();
//
//    public static void main(String[] args) {
//        launch(args);
//    }
//
//    @Override
//    public void start(Stage primaryStage) throws Exception {
//        // 初始化汇率
//        rates.put("CNY", BigDecimal.valueOf(1));
//        rates.put("USD", BigDecimal.valueOf(6.48));
//        rates.put("EUR", BigDecimal.valueOf(7.81));
//        rates.put("JPY", BigDecimal.valueOf(0.062));
//
//        // 创建数字转换标签页
//        Tab numTab = new Tab("数字转换");
//        VBox numVBox = new VBox();
//        numVBox.setAlignment(Pos.CENTER);
//        numVBox.setSpacing(20);
//        numVBox.setPadding(new Insets(50));
//        TextField numInput = new TextField();
//        Label numResult = new Label();
//        Button numBtn = new Button("转换");
//        numBtn.setOnAction(e -> {
//            String text = numInput.getText().trim();
//            if (!isValidNum(text)) {
//                numResult.setText("无效的输入");
//                return;
//            }
//            BigDecimal num = new BigDecimal(text);
//            String result = numToChinese(num);
//            numResult.setText(result);
//        });
//        numVBox.getChildren().addAll(new Label("输入数字金额："), numInput, numBtn, new Label("转换结果："), numResult);
//        numTab.setContent(numVBox);
//
//        // 创建汇率转换标签页
//        Tab rateTab = new Tab("汇率转换");
//        GridPane rateGrid = new GridPane();
//        rateGrid.setAlignment(Pos.CENTER);
//        rateGrid.setPadding(new Insets(50));
//        rateGrid.setHgap(20);
//        rateGrid.setVgap(20);
//        ComboBox<String> fromCombo = new ComboBox<>();
//        fromCombo.getItems().addAll("CNY", "USD", "EUR", "JPY");
//        ComboBox<String> toCombo = new ComboBox<>();
//        toCombo.getItems().addAll("CNY", "USD", "EUR", "JPY");
//        TextField rateInput = new TextField();
//        TextField rateRate = new TextField("6.48"); // 默认汇率
//        rateRate.setPromptText("输入汇率");
//        rateGrid.addRow(0, new Label("转换货币："), fromCombo, new Label("转换为："), toCombo);
//        rateGrid.addRow(1, new Label("输入金额："), rateInput, new Label("当前汇率："), rateRate);
//        Label rateResult = new Label();
//        Button rateBtn = new Button("转换");
//        rateBtn.setOnAction(e -> {
//            String fromCurrency = fromCombo.getValue();
//            String toCurrency = toCombo.getValue();
//            if (fromCurrency == null || toCurrency == null || fromCurrency.equals(toCurrency)) {
//                rateResult.setText("无效的输入");
//                return;
//            }
//            String text = rateInput.getText().trim();
//            if (!isValidNum(text)) {
//                rateResult.setText("无效的输入");
//                return;
//            }
//            BigDecimal num = new BigDecimal(text);
//            BigDecimal rate = BigDecimal.valueOf(6.48); // 默认汇率
//            String rateText = rateRate.getText().trim();
//            if (isValidNum(rateText)) {
//                rate = new BigDecimal(rateText);
//            }
//            BigDecimal result = convertCurrency(num, fromCurrency, toCurrency, rate);
//            rateResult.setText(result.toString());
//        });
//        rateGrid.addRow(2, rateBtn, new Label("转换结果："), rateResult);
//        rateTab.setContent(rateGrid);
//
//        // 创建选项卡面板
//        TabPane tabPane = new TabPane(numTab, rateTab);
//
//        // 创建场景
//        Scene scene = new Scene(tabPane, 600, 400);
//
//        // 显示窗口
//        primaryStage.setTitle("货币转换");
//        primaryStage.setScene(scene);
//        primaryStage.show();
//    }
//
//    // 数字转换方法
//    private String numToChinese(BigDecimal num) {
//        if (num.compareTo(BigDecimal.ZERO) == 0) {
//            return "零元整";
//        }
//        String[] chineseNumber = {"零", "壹", "贰", "叁", "肆", "伍", "陆",
//                "柒", "捌", "玖"};
//        String[] units = {"元", "拾", "佰", "仟", "万", "亿"};
//        StringBuilder result = new StringBuilder();
//        String numStr = num.stripTrailingZeros().toPlainString(); // 去掉末尾的零
//        int index = numStr.indexOf(".");
//        if (index == -1) {
//            index = numStr.length();
//        }
//        String integerPart = numStr.substring(0, index);
//        for (int i = 0; i < integerPart.length(); i++) {
//            int digit = Character.getNumericValue(integerPart.charAt(i));
//            int unitIndex = integerPart.length() - i - 1;
//            if (digit != 0 || unitIndex % 4 == 0) {
//                result.append(chineseNumber[digit]).append(units[unitIndex % 4]);
//            }
//            if (unitIndex % 4 == 0) {
//                result.append(units[4 + unitIndex / 4]);
//            }
//        }
//        if (index < numStr.length()) {
//            String decimalPart = numStr.substring(index + 1);
//            for (int i = 0; i < decimalPart.length(); i++) {
//                int digit = Character.getNumericValue(decimalPart.charAt(i));
//                if (digit != 0) {
//                    result.append(chineseNumber[digit]).append(units[i - decimalPart.length() - 1]);
//                }
//            }
//        }
//        if (result.charAt(0) == '零') {
//            result.deleteCharAt(0);
//        }
//        if (result.charAt(result.length() - 1) == '元') {
//            result.append("整");
//        }
//        return result.toString();
//    }
//
//    // 货币转换方法
//    private BigDecimal convertCurrency(BigDecimal num, String fromCurrency, String toCurrency, BigDecimal rate) {
//        BigDecimal fromRate = rates.get(fromCurrency);
//        BigDecimal toRate = rates.get(toCurrency);
//        BigDecimal toNum = num.multiply(fromRate).divide(toRate, 2, RoundingMode.HALF_UP);
//        return toNum;
//    }
//
//    // 判断输入是否为有效数字
//    private boolean isValidNum(String text) {
//        if (text == null || text.isEmpty()) {
//            return false;
//        }
//        try {
//            new BigDecimal(text);
//            return true;
//        } catch (NumberFormatException e) {
//            return false;
//        }
//    }
//
//}

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import java.util.Vector;

//import java.awt.*;
//import javax.swing.JFrame;
//import javax.swing.JPanel;
//import javax.swing.JTabbedPane;
//
//public class MyFrame extends JFrame {
//
//    private JTabbedPane tabbedPane;
//
//    public MyFrame() {
//
//        initUI();
//    }
//
//    private void initUI() {
//
//        tabbedPane = new JTabbedPane();
//        createTab1();
//        createTab2();
//
//        add(tabbedPane);
//
//        setTitle("My Frame");
//        setSize(300, 200);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(EXIT_ON_CLOSE);
//    }
//
//    private void createTab1() {
//
//        JPanel panel = new JPanel();
//
//
//
//        tabbedPane.addTab("Tab 1", panel);
//    }
//
//    private void createTab2() {
//
//        JPanel panel = new JPanel();
//
//
//
//        tabbedPane.addTab("Tab 2", panel);
//    }
//
//    public static void main(String[] args) {
//
//        EventQueue.invokeLater(() -> {
//
//            MyFrame frame = new MyFrame();
//            frame.setVisible(true);
//        });
//    }
//}
//public class Test {
//    public static void main(String[] args) {
//        Vector<String> vector = new Vector<String>();
//        File file = new File("src/main/java/Rate/CurrencysData.txt");
//        try (Scanner fr = new Scanner(new FileReader(file))) {
//            while (fr.hasNextLine()) {
//                String country = fr.next();
////                String f = fr.next();
////                String code = fr.next();
//                vector.add(country);
//                System.out.println(vector.toString());
//            }
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        }
//    }
//}
import javax.swing.*;
import java.awt.event.*;

public class Test {
    public static void main(String[] args) {
        JFrame frame = new JFrame("ComboBox Mouse Listener Example");

        JComboBox<String> myComboBox = new JComboBox<>(new String[] {"Apple", "Orange", "Banana"});

        MouseListener listener = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                JComboBox comboBox = (JComboBox) e.getSource();
                int index = comboBox.getSelectedIndex();
                String selectedItem = (String) comboBox.getSelectedItem();
                System.out.println("Selected Index: " + index);
                System.out.println("Selected Item: " + selectedItem);
            }
        };

        myComboBox.addMouseListener(listener);

        frame.add(myComboBox);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}