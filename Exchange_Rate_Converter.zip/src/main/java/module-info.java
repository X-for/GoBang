module exchange_Rate_Converter {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens exchange_Rate_Converter to javafx.fxml;
    exports exchange_Rate_Converter;
}