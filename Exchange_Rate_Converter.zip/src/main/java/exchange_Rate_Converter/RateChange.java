package exchange_Rate_Converter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

class RateChange extends JPanel {

    static File[] rateTxt = new File[]{
            new File("src/main/java/Rate/CNY.txt"),
            new File("src/main/java/Rate/CAD.txt"),
            new File("src/main/java/Rate/CHF.txt"),
            new File("src/main/java/Rate/EUR.txt"),
            new File("src/main/java/Rate/GBP.txt"),
            new File("src/main/java/Rate/HKD.txt"),
            new File("src/main/java/Rate/JPY.txt"),
            new File("src/main/java/Rate/KRW.txt"),
            new File("src/main/java/Rate/MOP.txt"),
            new File("src/main/java/Rate/RUB.txt"),
            new File("src/main/java/Rate/SGD.txt"),
            new File("src/main/java/Rate/THB.txt"),
            new File("src/main/java/Rate/TWD.txt"),
            new File("src/main/java/Rate/USD.txt")
    };
    static HashMap<String, BigDecimal> currencys = new HashMap<>();

    public RateChange() {
        this.setLayout(new BorderLayout());

        rateChangeTab();
    }

    public void findCurrencys() { // 获取所有国家汇率计算的hash表

        // 建立一个hash表 将所有 中国对所有国家的汇率算出来 1 元人民币换多少外币
        currencys.put("CNY", new BigDecimal("1"));
        for (File file : rateTxt) {
            try (Scanner fr = new Scanner(new FileReader(file))) {
                while (fr.hasNextLine()) {
                    String txt = fr.next();
                    String twoCurrencys = fr.next();
                    double rate = fr.nextDouble();
                    String date = fr.next();
                    String time = fr.next();
                    String[] cur = twoCurrencys.split("/");
                    // 如果存在这个国家对人民币的汇率就不需要转换了
                    if (!currencys.containsKey(cur[1])) {
                        BigDecimal put_Rate = currencys.get(cur[0]).multiply(BigDecimal.valueOf(rate));
                        currencys.put(cur[1], put_Rate);
                    }
                }
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public double moneyChange(String first, String second) {
        findCurrencys();
        if (currencys.containsKey(first) && currencys.containsKey(second) && currencys.get(second).compareTo(BigDecimal.ZERO) != 0) {
            return currencys.get(second).divide(currencys.get(first), 5, BigDecimal.ROUND_HALF_UP).doubleValue();
        }
        return -1;
    }


    // 在窗口中设计一个 汇率转换标签页
     public void rateChangeTab() {
         HashMap<String, List<String>> countryInf = new HashMap<>();

//        // 测试代码块
//        RateChange.findCurrencys();
//        System.out.println(RateChange.currencys.get("GMD"));
//        // 测试代码块

        JPanel panel = new JPanel(new GridBagLayout());

        Vector<String> vector = new Vector<String>();
        File file = new File("src/main/java/Rate/CurrencysData.txt");
        try (Scanner fr = new Scanner(new FileReader(file))) {
            while (fr.hasNextLine()) {
                String country = fr.next();
//                String f = fr.next();
//                String code = fr.next();
//                文件更新后读取
//                var temp = new ArrayList<String>();
//                temp.add(Integer.parseInt(f),code);
//                countryInf.put(country,temp);
                vector.add(country);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        // 设置下拉列表1
        JComboBox<String> jcBox1 = new JComboBox<>(vector);

        GridBagConstraints pla1 = new GridBagConstraints();
        pla1.gridx = 0;
        pla1.gridy = 0;
        pla1.weightx = 1.0;
        pla1.weighty = 1.0;
        pla1.fill = GridBagConstraints.NONE;
        pla1.anchor = GridBagConstraints.NORTHWEST;
        pla1.insets = new Insets(10, 10, 10, 10);

        JLabel label1 = new JLabel("选择兑换所使用的货币");
        JPanel labelPanel1 = new JPanel(new BorderLayout());
        JPanel tabBox1 = new JPanel();
        labelPanel1.add(label1, BorderLayout.WEST);
        labelPanel1.add(Box.createHorizontalStrut(10), BorderLayout.CENTER);
        labelPanel1.add(jcBox1, BorderLayout.EAST);
        panel.add(labelPanel1, pla1);
        panel.add(jcBox1,pla1);
        // 设置下列表1完成

        // 设置下拉列表2
        JComboBox<String> jcBox2 = new JComboBox<>(vector);

        GridBagConstraints pla2 = new GridBagConstraints();
        pla2.gridx = 1;
        pla2.gridy = 0;
        pla2.weightx = 1.0;
        pla2.weighty = 1.0;
        pla2.fill = GridBagConstraints.NONE;
        pla2.anchor = GridBagConstraints.NORTHWEST;
        pla2.insets = new Insets(10, 0, 10, 10);

        JLabel label2 = new JLabel("想要兑换的货币");
        JPanel labelPanel2 = new JPanel(new BorderLayout());
        labelPanel2.add(label2, BorderLayout.WEST);
        labelPanel2.add(Box.createHorizontalStrut(10), BorderLayout.CENTER);
        labelPanel2.add(jcBox2, BorderLayout.EAST);
        panel.add(labelPanel2, pla2);
//        panel.add(jcBox2,pla2);
//         设置下列表2完成
//
//         设置下拉列表选择之后用户会得到关于两国之间汇率和和货币符号缩写的信息


//        // 采用鼠标监听器来监听jcBox1和2的下拉选择框选择了什么
//        MouseListener countrySelection = new MouseListener() {
//            @Override
//            public void mouseClicked(MouseEvent e) {
//
//            }
//            @Override
//            public void mousePressed(MouseEvent e) {
//                String country_1 = (String) jcBox1.getSelectedItem();
//                String country_2 = (String) jcBox2.getSelectedItem();
//
//                JTextField message = new JTextField(country_1 + "对\n" + country_2 + "的汇率是\n");
//                // 设置文本框为不可编辑
//                message.setEditable(false);
//                // 设置文本框背景颜色、字体颜色、前景颜色
//                message.setBackground(Color.BLUE);
//                message.setForeground(Color.BLACK);
//                message.setFont(new Font("宋体", Font.BOLD, 20));
//                // 设置文本框长宽
//                message.setPreferredSize(new Dimension(200, 50));
//
//                GridBagConstraints pla3 = new GridBagConstraints();
//                pla3.gridx = 0;
//                pla3.gridy = 1;
//                pla3.weightx = 1.0;
//                pla3.weighty = 1.0;
//                pla3.fill = GridBagConstraints.NONE;
//                pla3.anchor = GridBagConstraints.NORTHWEST;
//                pla3.insets = new Insets(10, 0, 10, 10);
//                panel.add(message, pla3);
//            }
//
//            @Override
//            public void mouseReleased(MouseEvent e) {
//
//            }
//
//            @Override
//            public void mouseEntered(MouseEvent e) {
//
//            }
//
//            @Override
//            public void mouseExited(MouseEvent e) {
//
//            }
//        };
//        jcBox1.addMouseListener(countrySelection);
//        jcBox2.addMouseListener(countrySelection);


//        //Test2 采用内部匿名类动作监听器来监听jcBox1和2的下拉选择框选择了什么
//        ActionListener countrySelection = e -> {
//            String country_1 = (String) jcBox1.getSelectedItem();
//            String country_2 = (String) jcBox2.getSelectedItem();
//
//            JTextField message = new JTextField(country_1 + "对\n" + country_2 + "的汇率是\n");
//            // 设置文本框为不可编辑
//            message.setEditable(false);
//            // 设置文本框背景颜色、字体颜色、前景颜色
//            message.setBackground(Color.BLUE);
//            message.setForeground(Color.BLACK);
//            message.setFont(new Font("宋体", Font.BOLD, 20));
//            // 设置文本框长宽
//            message.setPreferredSize(new Dimension(200, 50));
//
//            GridBagConstraints pla3 = new GridBagConstraints();
//            pla3.gridx = 0;
//            pla3.gridy = 1;
//            pla3.weightx = 1.0;
//            pla3.weighty = 1.0;
//            pla3.fill = GridBagConstraints.NONE;
//            pla3.anchor = GridBagConstraints.NORTHWEST;
//            pla3.insets = new Insets(10, 0, 10, 10);
//
//            panel.add(message, pla3);
//
//        };
//
//        jcBox1.addActionListener(countrySelection);
//        jcBox2.addActionListener(countrySelection);


        // Test3 采用ItemListener来监听
        ItemListener countrySeletion = e -> {
            if (e.getStateChange() == ItemEvent.SELECTED){
                String country_1 = (String) jcBox1.getSelectedItem();
                String country_2 = (String) jcBox2.getSelectedItem();

                JTextField message = new JTextField(country_1 + "对\n" + country_2 + "的汇率是\n");
                // 设置文本框为不可编辑
                message.setEditable(false);
                // 设置文本框背景颜色、字体颜色、前景颜色
                message.setBackground(Color.BLUE);
                message.setForeground(Color.BLACK);
                message.setFont(new Font("宋体", Font.BOLD, 20));
                // 设置文本框长宽
                message.setPreferredSize(new Dimension(200, 50));

                GridBagConstraints pla3 = new GridBagConstraints();
                pla3.gridx = 0;
                pla3.gridy = 1;
                pla3.weightx = 1.0;
                pla3.weighty = 1.0;
                pla3.fill = GridBagConstraints.NONE;
                pla3.anchor = GridBagConstraints.NORTHWEST;
                pla3.insets = new Insets(10, 0, 10, 10);

                panel.add(message, pla3);
            }
        };
        jcBox1.addItemListener(countrySeletion);
        jcBox2.addItemListener(countrySeletion);

    }

}