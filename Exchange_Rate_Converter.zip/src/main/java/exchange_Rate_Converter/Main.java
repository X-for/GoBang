package exchange_Rate_Converter;

import java.awt.*;

public class Main {
    public static void main(String[] args) {

        EventQueue.invokeLater(() -> {

            MyChangeWindow window = new MyChangeWindow();

            window.setVisible(true);
        });
    }
}
